import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, existsSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
const cli = new URL('../bin/cli.js', import.meta.url).pathname;
function temp() { return mkdtempSync(join(tmpdir(), 'vdma-')); }
function run(args, cwd = temp()) { return spawnSync(process.execPath, [cli, ...args], { cwd, encoding: 'utf8' }); }
test('help works', () => { const r = run(['--help']); assert.equal(r.status, 0); assert.match(r.stdout, /Commands/); });
test('version works', () => { const r = run(['--version']); assert.equal(r.status, 0); assert.match(r.stdout.trim(), /\d+\.\d+\.\d+/); });
test('init creates missing files', () => { const cwd = temp(); const r = run(['init'], cwd); assert.equal(r.status, 0); assert.ok(existsSync(join(cwd, 'PRODUCT.md'))); assert.ok(existsSync(join(cwd, 'DESIGN.md'))); assert.ok(existsSync(join(cwd, 'AGENT.md'))); });
test('dry-run does not write files', () => { const cwd = temp(); const r = run(['init', '--dry-run'], cwd); assert.equal(r.status, 0); assert.equal(existsSync(join(cwd, 'PRODUCT.md')), false); });
test('autopilot writes reports', () => { const cwd = temp(); const r = run(['autopilot', '--report'], cwd); assert.equal(r.status, 0); assert.ok(existsSync(join(cwd, '.vibe-design/report.json'))); });
test('json report is valid', () => { const cwd = temp(); const r = run(['audit', '--json'], cwd); assert.equal(r.status, 0); assert.doesNotThrow(() => JSON.parse(r.stdout)); });
test('ci exits non-zero on errors', () => { const cwd = temp(); const r = run(['audit', '--ci'], cwd); assert.notEqual(r.status, 0); });
test('security rule catches unmasked key wording', () => { const cwd = temp(); run(['init'], cwd); writeFileSync(join(cwd, 'DESIGN.md'), '# DESIGN.md\nShow API key in table.'); const data = JSON.parse(run(['audit', '--json'], cwd).stdout); assert.ok(data.issues.some(i => i.id === 'api-key-masking')); });
test('accessibility rule catches modal without focus trap', () => { const cwd = temp(); run(['init'], cwd); writeFileSync(join(cwd, 'DESIGN.md'), '# DESIGN.md\nUse a modal for login.'); const data = JSON.parse(run(['audit', '--json'], cwd).stdout); assert.ok(data.issues.some(i => i.id === 'modal-without-focus-trap')); });
test('responsive rule catches height 100vh', () => { const cwd = temp(); run(['init'], cwd); writeFileSync(join(cwd, 'DESIGN.md'), '# DESIGN.md\nUse height: 100vh on auth page.'); const data = JSON.parse(run(['audit', '--json'], cwd).stdout); assert.ok(data.issues.some(i => i.id === 'height-100vh-mobile-risk')); });
