# Agent Workflow

1. Run `vibe-design-md-architect autopilot --report`.
2. Read PRODUCT.md, DESIGN.md, AGENT.md.
3. Fix manual items from `.vibe-design/fix-list.md`.
4. Ask the coding agent to inspect first, then implement narrowly.
5. Verify build, tests, mobile, accessibility, and UX states.
