# Rules

Rules have id, title, category, severity, explanation, repairability, and suggested fix. Prefer practical pattern detection over brittle exact strings.
