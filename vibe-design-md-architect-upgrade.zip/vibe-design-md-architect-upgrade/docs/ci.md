# CI Usage

Use strict audit mode in CI:

```bash
npx vibe-design-md-architect audit --ci --json
```
