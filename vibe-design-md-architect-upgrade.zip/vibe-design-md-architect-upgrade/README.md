# vibe-design-md-architect

A pre-agent quality gate for AI-assisted frontend work.

Run it before Cursor, Claude Code, AI Studio, Bolt, Windsurf, or any other coding agent starts editing your app.

```bash
npx vibe-design-md-architect autopilot
```

It creates or checks `PRODUCT.md`, `DESIGN.md`, and `AGENT.md`, then runs quality gates that catch weak specs, missing UX states, accessibility gaps, mobile layout risks, security display issues, and regression-prone agent instructions.

## Why this exists

AI coding agents often fail because the handoff is vague. They redesign things you did not ask for. They remove features. They miss mobile states. They show tokens in tables. They build modals without focus management. This tool puts a design and product contract in front of the agent.

## Commands

```bash
vibe-design-md-architect init
vibe-design-md-architect audit
vibe-design-md-architect repair
vibe-design-md-architect report
vibe-design-md-architect doctor
vibe-design-md-architect autopilot
```

## Common workflow

```bash
npx vibe-design-md-architect autopilot --report
cat .vibe-design/fix-list.md
```

Then paste this to your coding agent:

> Inspect PRODUCT.md, DESIGN.md, and AGENT.md. Implement only the requested scope. Preserve existing behavior. Verify mobile, accessibility, loading, empty, and error states before finalizing.

## Flags

- `--dry-run`: preview writes
- `--json`: machine-readable output
- `--report`: write `.vibe-design` reports
- `--ci`: fail on errors
- `--strict`: fail on errors
- `--verbose`: extra details
- `--no-color`: plain output

## Quality gates

The rule engine checks product clarity, UX completeness, accessibility, responsive design, security/privacy, agent handoff readiness, regression protection, content quality, implementation readiness, and risk control.

Examples:

- Missing target users
- Missing acceptance criteria
- Missing loading, empty, and error states
- Modal without focus trap
- `height: 100vh` mobile risk
- Token/API key display without masking
- Missing do-not-break rules
- Vague phrases like “make it modern”

## Safe repair policy

Auto-repair only appends safe missing sections or creates missing artifact files. It does not invent business claims, overwrite user content, remove sections, or change app source code.

## CI

```bash
npx vibe-design-md-architect audit --ci --json
```

## License

MIT
