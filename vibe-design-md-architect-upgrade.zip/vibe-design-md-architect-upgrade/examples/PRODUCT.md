# PRODUCT.md

## Product Summary
Example product specification.

## Target Users
- Product builder using AI coding agents.

## Acceptance Criteria
- Given a valid artifact set, audit returns no errors.
