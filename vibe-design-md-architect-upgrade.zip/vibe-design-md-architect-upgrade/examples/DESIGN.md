# DESIGN.md

## Responsive Behavior
Mobile, tablet, and desktop behavior must be defined.

## Accessibility Requirements
Keyboard navigation and focus management must be covered.
