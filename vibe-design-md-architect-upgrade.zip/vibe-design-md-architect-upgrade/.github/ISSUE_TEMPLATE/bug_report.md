---
name: Bug report
about: Report a CLI bug
---

## Command

## Expected

## Actual

## Environment
