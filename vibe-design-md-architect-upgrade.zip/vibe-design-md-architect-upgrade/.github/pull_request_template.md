## Summary

## Checks
- [ ] Tests pass
- [ ] CLI smoke test passes
- [ ] Docs updated
