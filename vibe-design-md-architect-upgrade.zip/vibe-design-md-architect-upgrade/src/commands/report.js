import { runAudit } from '../core/auditor.js';
import { writeReports } from '../core/report.js';
import { printResult } from '../core/output.js';
export async function report({ cwd, flags }) { const result = runAudit(cwd); result.reportFiles = writeReports(cwd, result, flags); result.changed = result.reportFiles; result.nextCommand = 'Review .vibe-design/fix-list.md'; printResult(result, flags); return result; }
