import { runAudit, summarize } from '../core/auditor.js';
import { applyRepairs } from '../core/repair.js';
import { writeReports } from '../core/report.js';
import { printResult } from '../core/output.js';
export async function autopilot({ cwd, flags }) { const first = runAudit(cwd); const patch = applyRepairs(cwd, first.issues, flags); const finalAudit = runAudit(cwd); const result = summarize({ ...finalAudit, ...patch }); result.reportFiles = writeReports(cwd, result, flags); result.nextCommand = 'vibe-design-md-architect audit --strict'; printResult(result, flags); return result; }
