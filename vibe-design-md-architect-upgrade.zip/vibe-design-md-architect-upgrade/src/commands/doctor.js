import { existsSync, accessSync, constants } from 'node:fs';
import { resolve } from 'node:path';
import { summarize } from '../core/auditor.js';
import { printResult } from '../core/output.js';
export async function doctor({ cwd, flags }) { const issues = []; if (!existsSync(resolve(cwd, 'package.json'))) issues.push({ id: 'package-json-missing', title: 'package.json not found in current directory', category: 'runtime', severity: 'info', suggestedFix: 'Run from a project root.' }); try { accessSync(cwd, constants.W_OK); } catch { issues.push({ id: 'cwd-not-writable', title: 'Current directory is not writable', category: 'runtime', severity: 'error', suggestedFix: 'Fix permissions or choose another directory.' }); } const result = summarize({ issues, generated: [], changed: [], repairs: [] }); result.nextCommand = 'vibe-design-md-architect autopilot'; printResult(result, flags); return result; }
