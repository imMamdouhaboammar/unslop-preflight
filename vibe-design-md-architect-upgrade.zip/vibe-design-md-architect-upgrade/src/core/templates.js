export const productTemplate = `# PRODUCT.md

## Product Summary
Describe the product in plain language.

## Target Users
- Primary user:
- Secondary user:

## Jobs To Be Done
- When I..., I want to..., so I can...

## Main Use Cases
- 

## Non-Goals
- The MVP will not...

## Core User Flows
1. 

## Feature List
- 

## Functional Requirements
- 

## Acceptance Criteria
- Given..., when..., then...

## Constraints
- 

## Risk Notes
- 

## AI-Agent Implementation Boundaries
- Inspect existing files before editing.
- Change one feature area at a time.
- Preserve existing behavior unless explicitly instructed.
`;
export const designTemplate = `# DESIGN.md

## Design Principles
- Clear before clever.
- Mobile behavior must be explicit.
- Every interactive component needs loading, empty, error, disabled, hover, focus, and success states.

## Information Architecture
- 

## Main Screens
- 

## Component Inventory
- 

## Responsive Behavior
- Mobile:
- Tablet:
- Desktop:
- Avoid using height: 100vh on mobile without safe viewport handling such as min-height: 100dvh.

## Accessibility Requirements
- Keyboard navigation must work.
- Modals must trap focus, restore focus on close, and close with Escape.
- Color contrast must be checked.

## Interaction States
- Loading:
- Empty:
- Error:
- Disabled:
- Success:

## Form Behavior
- Validation:
- Error copy:
- Submission states:

## Visual Consistency Rules
- Reuse existing components before creating new ones.

## Layout Rules
- Avoid overflow: hidden as a layout bug mask.

## Content Tone
- Clear, direct, useful.

## Do-Not-Break Rules
- Do not remove existing routes, data flows, or user-facing behavior without explicit approval.

## Agent Handoff Instructions
- Inspect before coding.
- Summarize planned edits.
- Verify responsive and accessibility behavior after changes.
`;
export const agentTemplate = `# AGENT.md

## Read This First
Before coding, inspect PRODUCT.md, DESIGN.md, package.json, routing files, component structure, and any existing tests.

## What Not To Change
- Do not delete existing features.
- Do not rename public routes or exported APIs without explicit approval.
- Do not replace the design system with unrelated styling.

## Regression Guard
- Preserve existing behavior.
- Limit changes to the requested scope.
- Check git diff before finalizing.
- Add or update tests when behavior changes.

## Verification Checklist
- App builds.
- Main flows still work.
- Mobile layout checked.
- Keyboard navigation checked.
- Loading, empty, and error states checked.

## When To Stop
Stop and ask for review when a change requires deleting features, changing data models, altering auth/security behavior, or making broad redesign decisions.
`;
export function templateFor(file) { return file === 'PRODUCT.md' ? productTemplate : file === 'DESIGN.md' ? designTemplate : agentTemplate; }
