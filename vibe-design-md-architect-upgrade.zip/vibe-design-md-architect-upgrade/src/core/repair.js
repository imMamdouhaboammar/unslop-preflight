import { appendText, exists, writeText } from './filesystem.js';
import { templateFor } from './templates.js';
const autoSections = {
  'missing-target-users': ['PRODUCT.md', `## Target Users
- Primary user:
- Secondary user:`],
  'missing-acceptance-criteria': ['PRODUCT.md', `## Acceptance Criteria
- Given..., when..., then...`],
  'missing-non-goals': ['PRODUCT.md', `## Non-Goals
- The MVP will not...`],
  'missing-mobile-behavior': ['DESIGN.md', `## Responsive Behavior
- Mobile:
- Tablet:
- Desktop:
- Avoid height: 100vh on mobile unless safe viewport behavior is handled.`],
  'missing-tablet-behavior': ['DESIGN.md', `## Tablet Behavior
- Define tablet layout, spacing, and navigation behavior.`],
  'missing-loading-empty-error': ['DESIGN.md', `## Loading, Empty, and Error States
- Loading:
- Empty:
- Error:
- Disabled:
- Success:`],
  'missing-keyboard-navigation': ['DESIGN.md', `## Keyboard Navigation And Focus
- All interactive elements must be reachable by keyboard.
- Focus states must be visible.`],
  'modal-without-focus-trap': ['DESIGN.md', `## Modal Accessibility
- Trap focus while the modal is open.
- Close with Escape.
- Restore focus to the trigger on close.`],
  'missing-color-contrast': ['DESIGN.md', `## Color Contrast
- Check text and interactive elements against WCAG AA contrast expectations.`],
  'height-100vh-mobile-risk': ['DESIGN.md', `## Mobile Viewport Safety
- Avoid raw height: 100vh on mobile. Prefer min-height: 100dvh or documented safe viewport handling.`],
  'api-key-masking': ['DESIGN.md', `## Secret And Token Display Rules
- Never show full API keys, tokens, or secrets in UI. Mask or redact values by default.`],
  'missing-do-not-break': ['AGENT.md', `## Do-Not-Break Rules
- Preserve existing behavior.
- Do not delete routes, state, styles, tests, or data flows unless explicitly requested.`],
  'missing-verification-checklist': ['AGENT.md', `## Verification Checklist
- Build passes.
- Tests pass.
- Main flows checked.
- Mobile behavior checked.
- Accessibility basics checked.`]
};
export function applyRepairs(cwd, issues, flags = {}) {
  const generated = []; const changed = []; const repairs = [];
  for (const file of ['PRODUCT.md', 'DESIGN.md', 'AGENT.md']) if (!exists(cwd, file)) { writeText(cwd, file, templateFor(file), flags); generated.push(file); repairs.push({ file, action: 'created template' }); }
  for (const issue of issues) {
    if (issue.repairability !== 'auto' || issue.id.endsWith('-missing')) continue;
    const section = autoSections[issue.id]; if (!section) continue;
    appendText(cwd, section[0], `<!-- Added by vibe-design-md-architect safe repair -->\n${section[1]}`, flags);
    if (!changed.includes(section[0])) changed.push(section[0]);
    repairs.push({ file: section[0], rule: issue.id, action: 'appended safe section' });
  }
  return { generated, changed, repairs };
}
