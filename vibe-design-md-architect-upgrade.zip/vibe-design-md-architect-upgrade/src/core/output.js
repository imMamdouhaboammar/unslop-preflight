export function parseArgs(argv) {
  const flags = {}; const args = [];
  for (const item of argv) {
    if (item.startsWith('--')) { const [key, raw] = item.slice(2).split('='); flags[key.replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = raw ?? true; }
    else args.push(item);
  }
  return { command: args[0], args: args.slice(1), flags, cwd: process.cwd() };
}
export function printHelp() { console.log(`vibe-design-md-architect\n\nUsage:\n  vibe-design-md-architect <command> [flags]\n\nCommands:\n  autopilot    Run init, audit, safe repair, and final report\n  init         Create missing PRODUCT.md, DESIGN.md, and AGENT.md\n  audit        Run quality gates against artifact docs\n  repair       Append safe missing sections and checklists\n  report       Write .vibe-design/report.md and report.json\n  doctor       Check runtime and project assumptions\n\nFlags:\n  --dry-run    Preview writes without changing files\n  --json       Print machine-readable JSON\n  --report     Write reports to .vibe-design\n  --ci         Exit non-zero on errors\n  --strict     Treat errors as failing\n  --verbose    Show extra details\n  --no-color   Disable color output\n  --debug      Show stack traces\n  --help       Show help\n  --version    Show package version`); }
export function printResult(result, flags = {}) {
  if (flags.json) return console.log(JSON.stringify(result, null, 2));
  const s = result.summary;
  console.log(`\nVibe Design MD Architect`);
  console.log(`Score: ${s.score}/100 | Checks: ${s.checks} | Errors: ${s.errors} | Warnings: ${s.warnings} | Info: ${s.info}`);
  if (result.generated?.length) console.log(`Generated: ${result.generated.join(', ')}`);
  if (result.changed?.length) console.log(`Changed: ${result.changed.join(', ')}`);
  if (result.repairs?.length) console.log(`Auto-repaired: ${result.repairs.length}`);
  if (result.issues?.length) { console.log('\nIssues:'); for (const issue of result.issues) console.log(`- [${issue.severity}] ${issue.id}: ${issue.title}`); }
  if (result.nextCommand) console.log(`\nNext: ${result.nextCommand}`);
}
