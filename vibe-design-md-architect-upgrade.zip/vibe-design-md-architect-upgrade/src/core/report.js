import { writeText } from './filesystem.js';
export function buildMarkdownReport(result) {
  const lines = ['# Vibe Design MD Architect Report', '', `Score: ${result.summary.score}/100`, `Checks: ${result.summary.checks}`, `Errors: ${result.summary.errors}`, `Warnings: ${result.summary.warnings}`, `Info: ${result.summary.info}`, ''];
  if (result.issues.length) { lines.push('## Issues'); for (const i of result.issues) lines.push(`- **${i.severity}** ${i.id}: ${i.title}  `, `  Suggested fix: ${i.suggestedFix}`); }
  if (result.repairs?.length) { lines.push('', '## Auto Repairs'); for (const r of result.repairs) lines.push(`- ${r.file}: ${r.action}${r.rule ? ` (${r.rule})` : ''}`); }
  lines.push('', '## Suggested Next Agent Prompt', '', 'Inspect PRODUCT.md, DESIGN.md, and AGENT.md. Implement only the requested scope. Preserve existing behavior. Verify mobile, accessibility, loading, empty, and error states before finalizing.');
  return lines.join('\n');
}
export function writeReports(cwd, result, flags = {}) {
  const md = buildMarkdownReport(result);
  writeText(cwd, '.vibe-design/report.md', md, flags);
  writeText(cwd, '.vibe-design/report.json', JSON.stringify(result, null, 2), flags);
  writeText(cwd, '.vibe-design/fix-list.md', md, flags);
  return ['.vibe-design/report.md', '.vibe-design/report.json', '.vibe-design/fix-list.md'];
}
