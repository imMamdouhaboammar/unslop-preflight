const docs = ['PRODUCT.md', 'DESIGN.md', 'AGENT.md'];
const section = (name) => new RegExp(`(^|\n)#{1,3}\s+${escapeRegExp(name)}\s*($|\n)`, 'i');
const any = (terms) => new RegExp(terms.map(escapeRegExp).join('|'), 'i');
function escapeRegExp(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function has(doc, rx) { return rx.test(doc || ''); }
function rule(id, title, category, severity, file, test, suggestedFix, repairability = 'suggested') {
  return { id, title, category, severity, file, test, explanation: title, suggestedFix, repairability };
}
export const rules = [
  ...docs.map((file) => rule(`${file.toLowerCase().replace('.md','')}-missing`, `${file} is missing`, 'implementation-readiness', 'error', file, (ctx) => !ctx.files[file], `Create ${file}.`, 'auto')),
  rule('missing-target-users', 'PRODUCT.md needs target users', 'product-clarity', 'warning', 'PRODUCT.md', (ctx) => ctx.files['PRODUCT.md'] && !has(ctx.files['PRODUCT.md'], section('Target Users')), 'Add a Target Users section.', 'auto'),
  rule('missing-acceptance-criteria', 'PRODUCT.md needs acceptance criteria', 'implementation-readiness', 'warning', 'PRODUCT.md', (ctx) => ctx.files['PRODUCT.md'] && !has(ctx.files['PRODUCT.md'], section('Acceptance Criteria')), 'Add acceptance criteria.', 'auto'),
  rule('missing-non-goals', 'PRODUCT.md needs non-goals', 'risk-control', 'warning', 'PRODUCT.md', (ctx) => ctx.files['PRODUCT.md'] && !has(ctx.files['PRODUCT.md'], section('Non-Goals')), 'Add non-goals to protect scope.', 'auto'),
  rule('missing-mobile-behavior', 'DESIGN.md needs mobile behavior', 'responsive-design', 'warning', 'DESIGN.md', (ctx) => ctx.files['DESIGN.md'] && !has(ctx.files['DESIGN.md'], any(['mobile', 'responsive', 'breakpoint'])), 'Add explicit mobile behavior.', 'auto'),
  rule('missing-tablet-behavior', 'DESIGN.md needs tablet behavior', 'responsive-design', 'info', 'DESIGN.md', (ctx) => ctx.files['DESIGN.md'] && !has(ctx.files['DESIGN.md'], any(['tablet', 'md breakpoint'])), 'Add tablet behavior.', 'auto'),
  rule('missing-loading-empty-error', 'DESIGN.md needs loading, empty, and error states', 'ux-completeness', 'warning', 'DESIGN.md', (ctx) => Boolean(ctx.files['DESIGN.md']) && (!has(ctx.files['DESIGN.md'], any(['loading'])) || !has(ctx.files['DESIGN.md'], any(['empty state', 'empty'])) || !has(ctx.files['DESIGN.md'], any(['error state', 'error']))), 'Add loading, empty, and error state rules.', 'auto'),
  rule('missing-keyboard-navigation', 'DESIGN.md needs keyboard navigation rules', 'accessibility', 'warning', 'DESIGN.md', (ctx) => ctx.files['DESIGN.md'] && !has(ctx.files['DESIGN.md'], any(['keyboard', 'tab order', 'focus'])), 'Add keyboard and focus requirements.', 'auto'),
  rule('modal-without-focus-trap', 'Modal is mentioned without focus-trap behavior', 'accessibility', 'error', 'DESIGN.md', (ctx) => has(ctx.files['DESIGN.md'], /modal/i) && !has(ctx.files['DESIGN.md'], /focus\s*trap|trap\s*focus/i), 'Specify modal focus trap, Escape close, and focus restore.', 'auto'),
  rule('missing-color-contrast', 'DESIGN.md needs color contrast guidance', 'accessibility', 'info', 'DESIGN.md', (ctx) => ctx.files['DESIGN.md'] && !has(ctx.files['DESIGN.md'], any(['contrast', 'WCAG'])), 'Add color contrast requirement.', 'auto'),
  rule('height-100vh-mobile-risk', 'height: 100vh appears without mobile viewport caveat', 'responsive-design', 'error', 'DESIGN.md', (ctx) => /height\s*:\s*100vh/i.test(ctx.all) && !/100dvh|svh|mobile viewport|safe viewport/i.test(ctx.all), 'Use min-height: 100dvh or document mobile viewport caveat.', 'auto'),
  rule('overflow-hidden-risk', 'overflow: hidden may mask layout bugs', 'risk-control', 'warning', 'DESIGN.md', (ctx) => /overflow\s*:\s*hidden/i.test(ctx.all) && !/intentional|mask|clip|layout bug/i.test(ctx.all), 'Document why overflow hidden is needed or remove it.', 'suggested'),
  rule('api-key-masking', 'Secrets/API keys must be masked in UI', 'security-and-privacy', 'error', 'DESIGN.md', (ctx) => /api\s*key|token|secret/i.test(ctx.all) && !/mask|redact|hidden|••••|never display/i.test(ctx.all), 'Add masking/redaction rule for tokens and secrets.', 'auto'),
  rule('missing-do-not-break', 'Missing do-not-break regression rules', 'regression-protection', 'warning', 'AGENT.md', (ctx) => ctx.files['AGENT.md'] && !has(ctx.files['AGENT.md'], any(['do not break', 'regression', 'preserve existing'])), 'Add regression guard and do-not-break rules.', 'auto'),
  rule('vague-modern', 'Vague design language needs concrete criteria', 'content-quality', 'info', 'DESIGN.md', (ctx) => /make it modern|clean and modern|beautiful UI/i.test(ctx.all), 'Replace vague adjectives with layout, component, state, and interaction requirements.', 'manual'),
  rule('missing-verification-checklist', 'AGENT.md needs a verification checklist', 'agent-handoff-readiness', 'warning', 'AGENT.md', (ctx) => ctx.files['AGENT.md'] && !has(ctx.files['AGENT.md'], section('Verification Checklist')), 'Add verification checklist.', 'auto')
];
